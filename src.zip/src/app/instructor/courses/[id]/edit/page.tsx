'use client';

import { useParams } from 'next/navigation';
import { CourseEditView } from '@/components/course/course-edit-view';

export default function EditCoursePage() {
    const { id } = useParams() as { id: string };
    return <CourseEditView courseId={id} basePath="/instructor/courses" />;
}
