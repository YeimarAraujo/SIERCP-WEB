'use client';

import { useParams } from 'next/navigation';
import { CourseManagementView } from '@/components/course/course-management-view';

export default function InstructorCoursePage() {
    const { id } = useParams() as { id: string };
    return (
        <CourseManagementView
            courseId={id}
            basePath="/instructor/courses"
            monitorHref="/instructor/monitor"
        />
    );
}
